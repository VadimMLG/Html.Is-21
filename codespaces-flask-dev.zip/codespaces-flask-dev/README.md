# Gendalf ♥️ Flask

Это мой первый проект на Flask, который выложен в репозиторий GitHub!


Автор проекта: Досов Илья Константинович

To run this application:

```
flask --debug run
```
